const products = [
  {
    id: 123432,
    title: 'Amazon Kindle E-reader',
    quantity: 5,
    price: 79.99
  },
  {
    id: 123487932,
    title: 'Apple 10.5-Inch iPad Pro',
    quantity: 0,
    price: 649.99
  },
];

export default products;
